# online-phone-store
This project is about buying a phone. There are three types of users: admin, unrestricted users and registered users. Admin can login using username and password, add user, update user delete user and view order. Unregistered users can only view the home page and create an account. And registered users can use all features, for example, they can view the home page and select their brand and phone. and can place an order by giving some specific information.

