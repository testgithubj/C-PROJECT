﻿
namespace home
{
    partial class Form15
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form15));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.iconButton28 = new FontAwesome.Sharp.IconButton();
            this.xiaomibut = new FontAwesome.Sharp.IconButton();
            this.button1 = new System.Windows.Forms.Button();
            this.oppoBut = new FontAwesome.Sharp.IconButton();
            this.viviBut = new FontAwesome.Sharp.IconButton();
            this.SamsungBut = new FontAwesome.Sharp.IconButton();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel27 = new System.Windows.Forms.Panel();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.iconButton24 = new FontAwesome.Sharp.IconButton();
            this.panel23 = new System.Windows.Forms.Panel();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.iconButton20 = new FontAwesome.Sharp.IconButton();
            this.panel28 = new System.Windows.Forms.Panel();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.iconButton25 = new FontAwesome.Sharp.IconButton();
            this.panel16 = new System.Windows.Forms.Panel();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.iconButton13 = new FontAwesome.Sharp.IconButton();
            this.panel29 = new System.Windows.Forms.Panel();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.iconButton26 = new FontAwesome.Sharp.IconButton();
            this.panel15 = new System.Windows.Forms.Panel();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.iconButton12 = new FontAwesome.Sharp.IconButton();
            this.panel30 = new System.Windows.Forms.Panel();
            this.label53 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.iconButton27 = new FontAwesome.Sharp.IconButton();
            this.panel24 = new System.Windows.Forms.Panel();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.iconButton21 = new FontAwesome.Sharp.IconButton();
            this.panel14 = new System.Windows.Forms.Panel();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.iconButton11 = new FontAwesome.Sharp.IconButton();
            this.panel17 = new System.Windows.Forms.Panel();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.iconButton14 = new FontAwesome.Sharp.IconButton();
            this.panel25 = new System.Windows.Forms.Panel();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.iconButton22 = new FontAwesome.Sharp.IconButton();
            this.panel13 = new System.Windows.Forms.Panel();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.iconButton10 = new FontAwesome.Sharp.IconButton();
            this.panel12 = new System.Windows.Forms.Panel();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.iconButton9 = new FontAwesome.Sharp.IconButton();
            this.panel26 = new System.Windows.Forms.Panel();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.iconButton23 = new FontAwesome.Sharp.IconButton();
            this.panel18 = new System.Windows.Forms.Panel();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.iconButton15 = new FontAwesome.Sharp.IconButton();
            this.panel11 = new System.Windows.Forms.Panel();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.iconButton8 = new FontAwesome.Sharp.IconButton();
            this.panel10 = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.iconButton7 = new FontAwesome.Sharp.IconButton();
            this.panel19 = new System.Windows.Forms.Panel();
            this.panel20 = new System.Windows.Forms.Panel();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.iconButton17 = new FontAwesome.Sharp.IconButton();
            this.label31 = new System.Windows.Forms.Label();
            this.panel21 = new System.Windows.Forms.Panel();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.iconButton18 = new FontAwesome.Sharp.IconButton();
            this.label32 = new System.Windows.Forms.Label();
            this.panel22 = new System.Windows.Forms.Panel();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.iconButton19 = new FontAwesome.Sharp.IconButton();
            this.iconButton16 = new FontAwesome.Sharp.IconButton();
            this.panel9 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.iconButton6 = new FontAwesome.Sharp.IconButton();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.iconButton5 = new FontAwesome.Sharp.IconButton();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.iconButton4 = new FontAwesome.Sharp.IconButton();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.iconButton3 = new FontAwesome.Sharp.IconButton();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.iconButton2 = new FontAwesome.Sharp.IconButton();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.iconButton1 = new FontAwesome.Sharp.IconButton();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel27.SuspendLayout();
            this.panel23.SuspendLayout();
            this.panel28.SuspendLayout();
            this.panel16.SuspendLayout();
            this.panel29.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panel30.SuspendLayout();
            this.panel24.SuspendLayout();
            this.panel14.SuspendLayout();
            this.panel17.SuspendLayout();
            this.panel25.SuspendLayout();
            this.panel13.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel26.SuspendLayout();
            this.panel18.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel19.SuspendLayout();
            this.panel20.SuspendLayout();
            this.panel21.SuspendLayout();
            this.panel22.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(394, 806);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel2.Controls.Add(this.iconButton28);
            this.panel2.Controls.Add(this.xiaomibut);
            this.panel2.Controls.Add(this.button1);
            this.panel2.Controls.Add(this.oppoBut);
            this.panel2.Controls.Add(this.viviBut);
            this.panel2.Controls.Add(this.SamsungBut);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(394, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(970, 82);
            this.panel2.TabIndex = 1;
            // 
            // iconButton28
            // 
            this.iconButton28.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.iconButton28.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(236)))), ((int)(((byte)(232)))));
            this.iconButton28.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.iconButton28.FlatAppearance.BorderSize = 0;
            this.iconButton28.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton28.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.iconButton28.IconChar = FontAwesome.Sharp.IconChar.SignOutAlt;
            this.iconButton28.IconColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.iconButton28.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton28.IconSize = 20;
            this.iconButton28.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton28.Location = new System.Drawing.Point(869, 50);
            this.iconButton28.Name = "iconButton28";
            this.iconButton28.Size = new System.Drawing.Size(99, 24);
            this.iconButton28.TabIndex = 11;
            this.iconButton28.Text = "Sign out";
            this.iconButton28.UseVisualStyleBackColor = false;
            this.iconButton28.Click += new System.EventHandler(this.iconButton28_Click);
            // 
            // xiaomibut
            // 
            this.xiaomibut.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.xiaomibut.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.xiaomibut.FlatAppearance.BorderSize = 0;
            this.xiaomibut.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.xiaomibut.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.xiaomibut.ForeColor = System.Drawing.Color.LightGray;
            this.xiaomibut.IconChar = FontAwesome.Sharp.IconChar.None;
            this.xiaomibut.IconColor = System.Drawing.Color.Black;
            this.xiaomibut.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.xiaomibut.IconSize = 30;
            this.xiaomibut.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.xiaomibut.Location = new System.Drawing.Point(564, 22);
            this.xiaomibut.Name = "xiaomibut";
            this.xiaomibut.Size = new System.Drawing.Size(130, 38);
            this.xiaomibut.TabIndex = 14;
            this.xiaomibut.Tag = "Home";
            this.xiaomibut.Text = "xiaomi";
            this.xiaomibut.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            this.button1.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(236)))), ((int)(((byte)(232)))));
            this.button1.Location = new System.Drawing.Point(868, 21);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(99, 23);
            this.button1.TabIndex = 12;
            this.button1.Text = "Back";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // oppoBut
            // 
            this.oppoBut.BackColor = System.Drawing.Color.SeaGreen;
            this.oppoBut.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.oppoBut.FlatAppearance.BorderSize = 0;
            this.oppoBut.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.oppoBut.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.oppoBut.ForeColor = System.Drawing.Color.Black;
            this.oppoBut.IconChar = FontAwesome.Sharp.IconChar.None;
            this.oppoBut.IconColor = System.Drawing.Color.Black;
            this.oppoBut.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.oppoBut.IconSize = 30;
            this.oppoBut.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.oppoBut.Location = new System.Drawing.Point(428, 21);
            this.oppoBut.Name = "oppoBut";
            this.oppoBut.Size = new System.Drawing.Size(130, 39);
            this.oppoBut.TabIndex = 13;
            this.oppoBut.Tag = "Home";
            this.oppoBut.Text = "OPPO ";
            this.oppoBut.UseVisualStyleBackColor = false;
            // 
            // viviBut
            // 
            this.viviBut.BackColor = System.Drawing.SystemColors.Highlight;
            this.viviBut.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.viviBut.FlatAppearance.BorderSize = 0;
            this.viviBut.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.viviBut.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.viviBut.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.viviBut.IconChar = FontAwesome.Sharp.IconChar.None;
            this.viviBut.IconColor = System.Drawing.Color.Black;
            this.viviBut.IconFont = FontAwesome.Sharp.IconFont.Solid;
            this.viviBut.IconSize = 30;
            this.viviBut.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.viviBut.Location = new System.Drawing.Point(310, 21);
            this.viviBut.Name = "viviBut";
            this.viviBut.Size = new System.Drawing.Size(112, 38);
            this.viviBut.TabIndex = 11;
            this.viviBut.Tag = "Home";
            this.viviBut.Text = "vivo";
            this.viviBut.UseVisualStyleBackColor = false;
            // 
            // SamsungBut
            // 
            this.SamsungBut.AutoEllipsis = true;
            this.SamsungBut.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.SamsungBut.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.SamsungBut.FlatAppearance.BorderSize = 0;
            this.SamsungBut.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SamsungBut.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            this.SamsungBut.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.SamsungBut.IconChar = FontAwesome.Sharp.IconChar.None;
            this.SamsungBut.IconColor = System.Drawing.Color.Black;
            this.SamsungBut.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.SamsungBut.IconSize = 30;
            this.SamsungBut.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SamsungBut.Location = new System.Drawing.Point(174, 21);
            this.SamsungBut.Name = "SamsungBut";
            this.SamsungBut.Size = new System.Drawing.Size(130, 38);
            this.SamsungBut.TabIndex = 10;
            this.SamsungBut.Tag = "Home";
            this.SamsungBut.Text = "Samsung";
            this.SamsungBut.UseVisualStyleBackColor = false;
            // 
            // panel3
            // 
            this.panel3.AutoScroll = true;
            this.panel3.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel3.Controls.Add(this.panel27);
            this.panel3.Controls.Add(this.panel23);
            this.panel3.Controls.Add(this.panel28);
            this.panel3.Controls.Add(this.panel16);
            this.panel3.Controls.Add(this.panel29);
            this.panel3.Controls.Add(this.panel15);
            this.panel3.Controls.Add(this.panel30);
            this.panel3.Controls.Add(this.panel24);
            this.panel3.Controls.Add(this.panel14);
            this.panel3.Controls.Add(this.panel17);
            this.panel3.Controls.Add(this.panel25);
            this.panel3.Controls.Add(this.panel13);
            this.panel3.Controls.Add(this.panel12);
            this.panel3.Controls.Add(this.panel26);
            this.panel3.Controls.Add(this.panel18);
            this.panel3.Controls.Add(this.panel11);
            this.panel3.Controls.Add(this.panel10);
            this.panel3.Controls.Add(this.panel19);
            this.panel3.Controls.Add(this.panel9);
            this.panel3.Controls.Add(this.panel8);
            this.panel3.Controls.Add(this.panel7);
            this.panel3.Controls.Add(this.panel6);
            this.panel3.Controls.Add(this.panel5);
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(394, 82);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(970, 724);
            this.panel3.TabIndex = 2;
            // 
            // panel27
            // 
            this.panel27.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel27.BackgroundImage")));
            this.panel27.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel27.Controls.Add(this.label47);
            this.panel27.Controls.Add(this.label48);
            this.panel27.Controls.Add(this.iconButton24);
            this.panel27.Location = new System.Drawing.Point(751, 2381);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(225, 358);
            this.panel27.TabIndex = 10;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(60, 309);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(66, 15);
            this.label47.TabIndex = 2;
            this.label47.Text = "Price: 3,789";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label48.Location = new System.Drawing.Point(3, 268);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(261, 21);
            this.label48.TabIndex = 1;
            this.label48.Text = "Nokia 110 4G 1.8\'\' Feature Phone";
            // 
            // iconButton24
            // 
            this.iconButton24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(236)))), ((int)(((byte)(232)))));
            this.iconButton24.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.iconButton24.IconChar = FontAwesome.Sharp.IconChar.ShoppingBasket;
            this.iconButton24.IconColor = System.Drawing.Color.Black;
            this.iconButton24.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton24.IconSize = 35;
            this.iconButton24.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton24.Location = new System.Drawing.Point(-2, 327);
            this.iconButton24.Name = "iconButton24";
            this.iconButton24.Size = new System.Drawing.Size(225, 29);
            this.iconButton24.TabIndex = 0;
            this.iconButton24.Text = "Buy";
            this.iconButton24.UseVisualStyleBackColor = false;
            // 
            // panel23
            // 
            this.panel23.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel23.BackgroundImage")));
            this.panel23.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel23.Controls.Add(this.label39);
            this.panel23.Controls.Add(this.label40);
            this.panel23.Controls.Add(this.iconButton20);
            this.panel23.Location = new System.Drawing.Point(753, 1895);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(225, 358);
            this.panel23.TabIndex = 10;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(51, 309);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(140, 15);
            this.label39.TabIndex = 2;
            this.label39.Text = "Official ✭\t৳16,499 4/64 GB";
            this.label39.Click += new System.EventHandler(this.label39_Click);
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label40.Location = new System.Drawing.Point(22, 268);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(181, 21);
            this.label40.TabIndex = 1;
            this.label40.Text = "Xiaomi Redmi Note 11";
            // 
            // iconButton20
            // 
            this.iconButton20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(236)))), ((int)(((byte)(232)))));
            this.iconButton20.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.iconButton20.IconChar = FontAwesome.Sharp.IconChar.ShoppingBasket;
            this.iconButton20.IconColor = System.Drawing.Color.Black;
            this.iconButton20.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton20.IconSize = 35;
            this.iconButton20.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton20.Location = new System.Drawing.Point(-2, 327);
            this.iconButton20.Name = "iconButton20";
            this.iconButton20.Size = new System.Drawing.Size(225, 29);
            this.iconButton20.TabIndex = 0;
            this.iconButton20.Text = "Buy";
            this.iconButton20.UseVisualStyleBackColor = false;
            // 
            // panel28
            // 
            this.panel28.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel28.BackgroundImage")));
            this.panel28.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel28.Controls.Add(this.label49);
            this.panel28.Controls.Add(this.label50);
            this.panel28.Controls.Add(this.iconButton25);
            this.panel28.Location = new System.Drawing.Point(517, 2381);
            this.panel28.Name = "panel28";
            this.panel28.Size = new System.Drawing.Size(225, 358);
            this.panel28.TabIndex = 7;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(67, 309);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(66, 15);
            this.label49.TabIndex = 2;
            this.label49.Text = "Price: 2,799";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label50.Location = new System.Drawing.Point(24, 268);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(160, 21);
            this.label50.TabIndex = 1;
            this.label50.Text = "Nokia 110 Dual Sim";
            // 
            // iconButton25
            // 
            this.iconButton25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(236)))), ((int)(((byte)(232)))));
            this.iconButton25.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.iconButton25.IconChar = FontAwesome.Sharp.IconChar.ShoppingBasket;
            this.iconButton25.IconColor = System.Drawing.Color.Black;
            this.iconButton25.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton25.IconSize = 35;
            this.iconButton25.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton25.Location = new System.Drawing.Point(-2, 327);
            this.iconButton25.Name = "iconButton25";
            this.iconButton25.Size = new System.Drawing.Size(225, 29);
            this.iconButton25.TabIndex = 0;
            this.iconButton25.Text = "Buy";
            this.iconButton25.UseVisualStyleBackColor = false;
            // 
            // panel16
            // 
            this.panel16.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel16.BackgroundImage")));
            this.panel16.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel16.Controls.Add(this.label25);
            this.panel16.Controls.Add(this.label26);
            this.panel16.Controls.Add(this.iconButton13);
            this.panel16.Location = new System.Drawing.Point(753, 1439);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(225, 358);
            this.panel16.TabIndex = 10;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(66, 298);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(72, 15);
            this.label25.TabIndex = 2;
            this.label25.Text = "Price: 22,990";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label26.Location = new System.Drawing.Point(58, 268);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(85, 21);
            this.label26.TabIndex = 1;
            this.label26.Text = "Oppo A95";
            this.label26.Click += new System.EventHandler(this.label26_Click);
            // 
            // iconButton13
            // 
            this.iconButton13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(236)))), ((int)(((byte)(232)))));
            this.iconButton13.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.iconButton13.IconChar = FontAwesome.Sharp.IconChar.ShoppingBasket;
            this.iconButton13.IconColor = System.Drawing.Color.Black;
            this.iconButton13.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton13.IconSize = 35;
            this.iconButton13.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton13.Location = new System.Drawing.Point(-2, 327);
            this.iconButton13.Name = "iconButton13";
            this.iconButton13.Size = new System.Drawing.Size(225, 29);
            this.iconButton13.TabIndex = 0;
            this.iconButton13.Text = "Buy";
            this.iconButton13.UseVisualStyleBackColor = false;
            // 
            // panel29
            // 
            this.panel29.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel29.BackgroundImage")));
            this.panel29.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel29.Controls.Add(this.label51);
            this.panel29.Controls.Add(this.label52);
            this.panel29.Controls.Add(this.iconButton26);
            this.panel29.Location = new System.Drawing.Point(264, 2381);
            this.panel29.Name = "panel29";
            this.panel29.Size = new System.Drawing.Size(225, 358);
            this.panel29.TabIndex = 9;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(66, 309);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(66, 15);
            this.label51.TabIndex = 2;
            this.label51.Text = "Price: 1,999";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label52.Location = new System.Drawing.Point(20, 279);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(173, 21);
            this.label52.TabIndex = 1;
            this.label52.Text = "Model: Nokia 106 DS ";
            this.label52.Click += new System.EventHandler(this.label52_Click);
            // 
            // iconButton26
            // 
            this.iconButton26.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(236)))), ((int)(((byte)(232)))));
            this.iconButton26.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.iconButton26.IconChar = FontAwesome.Sharp.IconChar.ShoppingBasket;
            this.iconButton26.IconColor = System.Drawing.Color.Black;
            this.iconButton26.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton26.IconSize = 35;
            this.iconButton26.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton26.Location = new System.Drawing.Point(-2, 327);
            this.iconButton26.Name = "iconButton26";
            this.iconButton26.Size = new System.Drawing.Size(225, 29);
            this.iconButton26.TabIndex = 0;
            this.iconButton26.Text = "Buy";
            this.iconButton26.UseVisualStyleBackColor = false;
            // 
            // panel15
            // 
            this.panel15.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel15.BackgroundImage")));
            this.panel15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel15.Controls.Add(this.label23);
            this.panel15.Controls.Add(this.label24);
            this.panel15.Controls.Add(this.iconButton12);
            this.panel15.Location = new System.Drawing.Point(753, 966);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(225, 358);
            this.panel15.TabIndex = 6;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(77, 289);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(66, 15);
            this.label23.TabIndex = 2;
            this.label23.Text = "BDT. 17,990";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label24.Location = new System.Drawing.Point(66, 268);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(86, 21);
            this.label24.TabIndex = 1;
            this.label24.Text = "Vivo Y21T";
            // 
            // iconButton12
            // 
            this.iconButton12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(236)))), ((int)(((byte)(232)))));
            this.iconButton12.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.iconButton12.IconChar = FontAwesome.Sharp.IconChar.ShoppingBasket;
            this.iconButton12.IconColor = System.Drawing.Color.Black;
            this.iconButton12.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton12.IconSize = 35;
            this.iconButton12.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton12.Location = new System.Drawing.Point(-2, 327);
            this.iconButton12.Name = "iconButton12";
            this.iconButton12.Size = new System.Drawing.Size(225, 29);
            this.iconButton12.TabIndex = 0;
            this.iconButton12.Text = "Buy";
            this.iconButton12.UseVisualStyleBackColor = false;
            // 
            // panel30
            // 
            this.panel30.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel30.BackgroundImage")));
            this.panel30.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel30.Controls.Add(this.label53);
            this.panel30.Controls.Add(this.label54);
            this.panel30.Controls.Add(this.iconButton27);
            this.panel30.Location = new System.Drawing.Point(13, 2381);
            this.panel30.Name = "panel30";
            this.panel30.Size = new System.Drawing.Size(225, 358);
            this.panel30.TabIndex = 8;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(51, 309);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(66, 15);
            this.label53.TabIndex = 2;
            this.label53.Text = "Price: 4,499";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label54.Location = new System.Drawing.Point(3, 268);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(93, 21);
            this.label54.TabIndex = 1;
            this.label54.Text = "nokia 5310";
            // 
            // iconButton27
            // 
            this.iconButton27.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(236)))), ((int)(((byte)(232)))));
            this.iconButton27.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.iconButton27.IconChar = FontAwesome.Sharp.IconChar.ShoppingBasket;
            this.iconButton27.IconColor = System.Drawing.Color.Black;
            this.iconButton27.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton27.IconSize = 35;
            this.iconButton27.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton27.Location = new System.Drawing.Point(-2, 327);
            this.iconButton27.Name = "iconButton27";
            this.iconButton27.Size = new System.Drawing.Size(225, 29);
            this.iconButton27.TabIndex = 0;
            this.iconButton27.Text = "Buy";
            this.iconButton27.UseVisualStyleBackColor = false;
            // 
            // panel24
            // 
            this.panel24.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel24.BackgroundImage")));
            this.panel24.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel24.Controls.Add(this.label41);
            this.panel24.Controls.Add(this.label42);
            this.panel24.Controls.Add(this.iconButton21);
            this.panel24.Location = new System.Drawing.Point(519, 1895);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(225, 358);
            this.panel24.TabIndex = 7;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(51, 309);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(146, 15);
            this.label41.TabIndex = 2;
            this.label41.Text = "Official ✭\t৳39,999 6/128 GB";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label42.Location = new System.Drawing.Point(3, 268);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(217, 21);
            this.label42.TabIndex = 1;
            this.label42.Text = "Xiaomi 11i Hypercharge 5G";
            this.label42.Click += new System.EventHandler(this.label42_Click);
            // 
            // iconButton21
            // 
            this.iconButton21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(236)))), ((int)(((byte)(232)))));
            this.iconButton21.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.iconButton21.IconChar = FontAwesome.Sharp.IconChar.ShoppingBasket;
            this.iconButton21.IconColor = System.Drawing.Color.Black;
            this.iconButton21.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton21.IconSize = 35;
            this.iconButton21.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton21.Location = new System.Drawing.Point(-2, 327);
            this.iconButton21.Name = "iconButton21";
            this.iconButton21.Size = new System.Drawing.Size(225, 29);
            this.iconButton21.TabIndex = 0;
            this.iconButton21.Text = "Buy";
            this.iconButton21.UseVisualStyleBackColor = false;
            // 
            // panel14
            // 
            this.panel14.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel14.BackgroundImage")));
            this.panel14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel14.Controls.Add(this.label21);
            this.panel14.Controls.Add(this.label22);
            this.panel14.Controls.Add(this.iconButton11);
            this.panel14.Location = new System.Drawing.Point(519, 966);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(225, 358);
            this.panel14.TabIndex = 3;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(81, 289);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(66, 15);
            this.label21.TabIndex = 2;
            this.label21.Text = "BDT. 20,990";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label22.Location = new System.Drawing.Point(78, 268);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(84, 21);
            this.label22.TabIndex = 1;
            this.label22.Text = "Vivo Y33s";
            // 
            // iconButton11
            // 
            this.iconButton11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(236)))), ((int)(((byte)(232)))));
            this.iconButton11.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.iconButton11.IconChar = FontAwesome.Sharp.IconChar.ShoppingBasket;
            this.iconButton11.IconColor = System.Drawing.Color.Black;
            this.iconButton11.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton11.IconSize = 35;
            this.iconButton11.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton11.Location = new System.Drawing.Point(-2, 327);
            this.iconButton11.Name = "iconButton11";
            this.iconButton11.Size = new System.Drawing.Size(225, 29);
            this.iconButton11.TabIndex = 0;
            this.iconButton11.Text = "Buy";
            this.iconButton11.UseVisualStyleBackColor = false;
            // 
            // panel17
            // 
            this.panel17.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel17.BackgroundImage")));
            this.panel17.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel17.Controls.Add(this.label27);
            this.panel17.Controls.Add(this.label28);
            this.panel17.Controls.Add(this.iconButton14);
            this.panel17.Location = new System.Drawing.Point(519, 1439);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(225, 358);
            this.panel17.TabIndex = 7;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(65, 298);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(72, 15);
            this.label27.TabIndex = 2;
            this.label27.Text = "Price: 20,990";
            this.label27.Click += new System.EventHandler(this.label27_Click);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label28.Location = new System.Drawing.Point(65, 268);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(82, 21);
            this.label28.TabIndex = 1;
            this.label28.Text = "Oppo F17";
            // 
            // iconButton14
            // 
            this.iconButton14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(236)))), ((int)(((byte)(232)))));
            this.iconButton14.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.iconButton14.IconChar = FontAwesome.Sharp.IconChar.ShoppingBasket;
            this.iconButton14.IconColor = System.Drawing.Color.Black;
            this.iconButton14.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton14.IconSize = 35;
            this.iconButton14.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton14.Location = new System.Drawing.Point(-2, 327);
            this.iconButton14.Name = "iconButton14";
            this.iconButton14.Size = new System.Drawing.Size(225, 29);
            this.iconButton14.TabIndex = 0;
            this.iconButton14.Text = "Buy";
            this.iconButton14.UseVisualStyleBackColor = false;
            // 
            // panel25
            // 
            this.panel25.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel25.BackgroundImage")));
            this.panel25.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel25.Controls.Add(this.label43);
            this.panel25.Controls.Add(this.label44);
            this.panel25.Controls.Add(this.iconButton22);
            this.panel25.Location = new System.Drawing.Point(266, 1895);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(225, 358);
            this.panel25.TabIndex = 9;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(51, 309);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(140, 15);
            this.label43.TabIndex = 2;
            this.label43.Text = "Official ✭\t৳14,999 4/64 GB";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label44.Location = new System.Drawing.Point(20, 268);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(179, 21);
            this.label44.TabIndex = 1;
            this.label44.Text = "Xiaomi Redmi 10 2022";
            // 
            // iconButton22
            // 
            this.iconButton22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(236)))), ((int)(((byte)(232)))));
            this.iconButton22.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.iconButton22.IconChar = FontAwesome.Sharp.IconChar.ShoppingBasket;
            this.iconButton22.IconColor = System.Drawing.Color.Black;
            this.iconButton22.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton22.IconSize = 35;
            this.iconButton22.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton22.Location = new System.Drawing.Point(-2, 327);
            this.iconButton22.Name = "iconButton22";
            this.iconButton22.Size = new System.Drawing.Size(225, 29);
            this.iconButton22.TabIndex = 0;
            this.iconButton22.Text = "Buy";
            this.iconButton22.UseVisualStyleBackColor = false;
            // 
            // panel13
            // 
            this.panel13.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel13.BackgroundImage")));
            this.panel13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel13.Controls.Add(this.label19);
            this.panel13.Controls.Add(this.label20);
            this.panel13.Controls.Add(this.iconButton10);
            this.panel13.Location = new System.Drawing.Point(266, 966);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(225, 358);
            this.panel13.TabIndex = 5;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(64, 298);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(66, 15);
            this.label19.TabIndex = 2;
            this.label19.Text = "BDT. 32,990";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label20.Location = new System.Drawing.Point(78, 268);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(39, 21);
            this.label20.TabIndex = 1;
            this.label20.Text = "V21";
            // 
            // iconButton10
            // 
            this.iconButton10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(236)))), ((int)(((byte)(232)))));
            this.iconButton10.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.iconButton10.IconChar = FontAwesome.Sharp.IconChar.ShoppingBasket;
            this.iconButton10.IconColor = System.Drawing.Color.Black;
            this.iconButton10.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton10.IconSize = 35;
            this.iconButton10.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton10.Location = new System.Drawing.Point(-2, 327);
            this.iconButton10.Name = "iconButton10";
            this.iconButton10.Size = new System.Drawing.Size(225, 29);
            this.iconButton10.TabIndex = 0;
            this.iconButton10.Text = "Buy";
            this.iconButton10.UseVisualStyleBackColor = false;
            // 
            // panel12
            // 
            this.panel12.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel12.BackgroundImage")));
            this.panel12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel12.Controls.Add(this.label17);
            this.panel12.Controls.Add(this.label18);
            this.panel12.Controls.Add(this.iconButton9);
            this.panel12.Location = new System.Drawing.Point(15, 966);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(225, 358);
            this.panel12.TabIndex = 3;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(67, 298);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(66, 15);
            this.label17.TabIndex = 2;
            this.label17.Text = "BDT. 39,990";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label18.Location = new System.Drawing.Point(78, 268);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(39, 21);
            this.label18.TabIndex = 1;
            this.label18.Text = "V23";
            // 
            // iconButton9
            // 
            this.iconButton9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(236)))), ((int)(((byte)(232)))));
            this.iconButton9.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.iconButton9.IconChar = FontAwesome.Sharp.IconChar.ShoppingBasket;
            this.iconButton9.IconColor = System.Drawing.Color.Black;
            this.iconButton9.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton9.IconSize = 35;
            this.iconButton9.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton9.Location = new System.Drawing.Point(-2, 327);
            this.iconButton9.Name = "iconButton9";
            this.iconButton9.Size = new System.Drawing.Size(225, 29);
            this.iconButton9.TabIndex = 0;
            this.iconButton9.Text = "Buy";
            this.iconButton9.UseVisualStyleBackColor = false;
            // 
            // panel26
            // 
            this.panel26.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel26.BackgroundImage")));
            this.panel26.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel26.Controls.Add(this.label45);
            this.panel26.Controls.Add(this.label46);
            this.panel26.Controls.Add(this.iconButton23);
            this.panel26.Location = new System.Drawing.Point(15, 1895);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(225, 358);
            this.panel26.TabIndex = 8;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(25, 309);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(187, 15);
            this.label45.TabIndex = 2;
            this.label45.Text = "Official ✭\t৳35,999 ৳39,999 6/128 GB";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label46.Location = new System.Drawing.Point(25, 268);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(168, 21);
            this.label46.TabIndex = 1;
            this.label46.Text = "Xiaomi 11 Lite 5G NE";
            // 
            // iconButton23
            // 
            this.iconButton23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(236)))), ((int)(((byte)(232)))));
            this.iconButton23.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.iconButton23.IconChar = FontAwesome.Sharp.IconChar.ShoppingBasket;
            this.iconButton23.IconColor = System.Drawing.Color.Black;
            this.iconButton23.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton23.IconSize = 35;
            this.iconButton23.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton23.Location = new System.Drawing.Point(-2, 327);
            this.iconButton23.Name = "iconButton23";
            this.iconButton23.Size = new System.Drawing.Size(225, 29);
            this.iconButton23.TabIndex = 0;
            this.iconButton23.Text = "Buy";
            this.iconButton23.UseVisualStyleBackColor = false;
            // 
            // panel18
            // 
            this.panel18.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel18.BackgroundImage")));
            this.panel18.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel18.Controls.Add(this.label29);
            this.panel18.Controls.Add(this.label30);
            this.panel18.Controls.Add(this.iconButton15);
            this.panel18.Location = new System.Drawing.Point(266, 1439);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(225, 358);
            this.panel18.TabIndex = 9;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(64, 298);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(72, 15);
            this.label29.TabIndex = 2;
            this.label29.Text = "Price: 32,990";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label30.Location = new System.Drawing.Point(51, 268);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(104, 21);
            this.label30.TabIndex = 1;
            this.label30.Text = "Oppo Reno5";
            // 
            // iconButton15
            // 
            this.iconButton15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(236)))), ((int)(((byte)(232)))));
            this.iconButton15.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.iconButton15.IconChar = FontAwesome.Sharp.IconChar.ShoppingBasket;
            this.iconButton15.IconColor = System.Drawing.Color.Black;
            this.iconButton15.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton15.IconSize = 35;
            this.iconButton15.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton15.Location = new System.Drawing.Point(-2, 327);
            this.iconButton15.Name = "iconButton15";
            this.iconButton15.Size = new System.Drawing.Size(225, 29);
            this.iconButton15.TabIndex = 0;
            this.iconButton15.Text = "Buy";
            this.iconButton15.UseVisualStyleBackColor = false;
            // 
            // panel11
            // 
            this.panel11.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel11.BackgroundImage")));
            this.panel11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel11.Controls.Add(this.label15);
            this.panel11.Controls.Add(this.label16);
            this.panel11.Controls.Add(this.iconButton8);
            this.panel11.Location = new System.Drawing.Point(755, 465);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(225, 358);
            this.panel11.TabIndex = 3;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(32, 309);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(140, 15);
            this.label15.TabIndex = 2;
            this.label15.Text = "Official ✭\t৳16,999 4/64 GB";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label16.Location = new System.Drawing.Point(32, 270);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(169, 21);
            this.label16.TabIndex = 1;
            this.label16.Text = "Samsung Galaxy A13";
            // 
            // iconButton8
            // 
            this.iconButton8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(236)))), ((int)(((byte)(232)))));
            this.iconButton8.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.iconButton8.IconChar = FontAwesome.Sharp.IconChar.ShoppingBasket;
            this.iconButton8.IconColor = System.Drawing.Color.Black;
            this.iconButton8.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton8.IconSize = 35;
            this.iconButton8.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton8.Location = new System.Drawing.Point(-2, 327);
            this.iconButton8.Name = "iconButton8";
            this.iconButton8.Size = new System.Drawing.Size(225, 29);
            this.iconButton8.TabIndex = 0;
            this.iconButton8.Text = "Buy";
            this.iconButton8.UseVisualStyleBackColor = false;
            // 
            // panel10
            // 
            this.panel10.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel10.BackgroundImage")));
            this.panel10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel10.Controls.Add(this.label13);
            this.panel10.Controls.Add(this.label14);
            this.panel10.Controls.Add(this.iconButton7);
            this.panel10.Location = new System.Drawing.Point(516, 467);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(225, 358);
            this.panel10.TabIndex = 3;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(37, 307);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(181, 15);
            this.label13.TabIndex = 2;
            this.label13.Text = "Official ✭\t৳16,999 ৳17,999 4/64 GB";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label14.Location = new System.Drawing.Point(37, 268);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(169, 21);
            this.label14.TabIndex = 1;
            this.label14.Text = "Samsung Galaxy A13";
            this.label14.Click += new System.EventHandler(this.label14_Click);
            // 
            // iconButton7
            // 
            this.iconButton7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(236)))), ((int)(((byte)(232)))));
            this.iconButton7.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.iconButton7.IconChar = FontAwesome.Sharp.IconChar.ShoppingBasket;
            this.iconButton7.IconColor = System.Drawing.Color.Black;
            this.iconButton7.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton7.IconSize = 35;
            this.iconButton7.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton7.Location = new System.Drawing.Point(-2, 327);
            this.iconButton7.Name = "iconButton7";
            this.iconButton7.Size = new System.Drawing.Size(225, 29);
            this.iconButton7.TabIndex = 0;
            this.iconButton7.Text = "Buy";
            this.iconButton7.UseVisualStyleBackColor = false;
            // 
            // panel19
            // 
            this.panel19.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel19.BackgroundImage")));
            this.panel19.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel19.Controls.Add(this.panel20);
            this.panel19.Controls.Add(this.label31);
            this.panel19.Controls.Add(this.panel21);
            this.panel19.Controls.Add(this.label32);
            this.panel19.Controls.Add(this.panel22);
            this.panel19.Controls.Add(this.iconButton16);
            this.panel19.Location = new System.Drawing.Point(15, 1439);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(225, 358);
            this.panel19.TabIndex = 8;
            // 
            // panel20
            // 
            this.panel20.BackgroundImage = global::home.Properties.Resources._221;
            this.panel20.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel20.Controls.Add(this.label33);
            this.panel20.Controls.Add(this.label34);
            this.panel20.Controls.Add(this.iconButton17);
            this.panel20.Location = new System.Drawing.Point(741, 259);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(225, 358);
            this.panel20.TabIndex = 14;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(51, 309);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(113, 15);
            this.label33.TabIndex = 2;
            this.label33.Text = "Official :162,999 BDT";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label34.Location = new System.Drawing.Point(3, 268);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(202, 21);
            this.label34.TabIndex = 1;
            this.label34.Text = "Apple iphone 13 pro max";
            // 
            // iconButton17
            // 
            this.iconButton17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(236)))), ((int)(((byte)(232)))));
            this.iconButton17.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.iconButton17.IconChar = FontAwesome.Sharp.IconChar.ShoppingBasket;
            this.iconButton17.IconColor = System.Drawing.Color.Black;
            this.iconButton17.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton17.IconSize = 35;
            this.iconButton17.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton17.Location = new System.Drawing.Point(-2, 327);
            this.iconButton17.Name = "iconButton17";
            this.iconButton17.Size = new System.Drawing.Size(225, 29);
            this.iconButton17.TabIndex = 0;
            this.iconButton17.Text = "Buy";
            this.iconButton17.UseVisualStyleBackColor = false;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(61, 298);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(72, 15);
            this.label31.TabIndex = 2;
            this.label31.Text = "Price: 32,990";
            // 
            // panel21
            // 
            this.panel21.BackgroundImage = global::home.Properties.Resources._221;
            this.panel21.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel21.Controls.Add(this.label35);
            this.panel21.Controls.Add(this.label36);
            this.panel21.Controls.Add(this.iconButton18);
            this.panel21.Location = new System.Drawing.Point(507, 259);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(225, 358);
            this.panel21.TabIndex = 11;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(51, 309);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(113, 15);
            this.label35.TabIndex = 2;
            this.label35.Text = "Official :162,999 BDT";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label36.Location = new System.Drawing.Point(3, 268);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(202, 21);
            this.label36.TabIndex = 1;
            this.label36.Text = "Apple iphone 13 pro max";
            // 
            // iconButton18
            // 
            this.iconButton18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(236)))), ((int)(((byte)(232)))));
            this.iconButton18.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.iconButton18.IconChar = FontAwesome.Sharp.IconChar.ShoppingBasket;
            this.iconButton18.IconColor = System.Drawing.Color.Black;
            this.iconButton18.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton18.IconSize = 35;
            this.iconButton18.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton18.Location = new System.Drawing.Point(-2, 327);
            this.iconButton18.Name = "iconButton18";
            this.iconButton18.Size = new System.Drawing.Size(225, 29);
            this.iconButton18.TabIndex = 0;
            this.iconButton18.Text = "Buy";
            this.iconButton18.UseVisualStyleBackColor = false;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label32.Location = new System.Drawing.Point(49, 268);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(104, 21);
            this.label32.TabIndex = 1;
            this.label32.Text = "Oppo Reno6";
            // 
            // panel22
            // 
            this.panel22.BackgroundImage = global::home.Properties.Resources._221;
            this.panel22.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel22.Controls.Add(this.label37);
            this.panel22.Controls.Add(this.label38);
            this.panel22.Controls.Add(this.iconButton19);
            this.panel22.Location = new System.Drawing.Point(254, 259);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(225, 358);
            this.panel22.TabIndex = 13;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(51, 309);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(113, 15);
            this.label37.TabIndex = 2;
            this.label37.Text = "Official :162,999 BDT";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label38.Location = new System.Drawing.Point(3, 268);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(202, 21);
            this.label38.TabIndex = 1;
            this.label38.Text = "Apple iphone 13 pro max";
            // 
            // iconButton19
            // 
            this.iconButton19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(236)))), ((int)(((byte)(232)))));
            this.iconButton19.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.iconButton19.IconChar = FontAwesome.Sharp.IconChar.ShoppingBasket;
            this.iconButton19.IconColor = System.Drawing.Color.Black;
            this.iconButton19.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton19.IconSize = 35;
            this.iconButton19.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton19.Location = new System.Drawing.Point(-2, 327);
            this.iconButton19.Name = "iconButton19";
            this.iconButton19.Size = new System.Drawing.Size(225, 29);
            this.iconButton19.TabIndex = 0;
            this.iconButton19.Text = "Buy";
            this.iconButton19.UseVisualStyleBackColor = false;
            // 
            // iconButton16
            // 
            this.iconButton16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(236)))), ((int)(((byte)(232)))));
            this.iconButton16.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.iconButton16.IconChar = FontAwesome.Sharp.IconChar.ShoppingBasket;
            this.iconButton16.IconColor = System.Drawing.Color.Black;
            this.iconButton16.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton16.IconSize = 35;
            this.iconButton16.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton16.Location = new System.Drawing.Point(-2, 327);
            this.iconButton16.Name = "iconButton16";
            this.iconButton16.Size = new System.Drawing.Size(225, 29);
            this.iconButton16.TabIndex = 0;
            this.iconButton16.Text = "Buy";
            this.iconButton16.UseVisualStyleBackColor = false;
            // 
            // panel9
            // 
            this.panel9.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel9.BackgroundImage")));
            this.panel9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel9.Controls.Add(this.label11);
            this.panel9.Controls.Add(this.label12);
            this.panel9.Controls.Add(this.iconButton6);
            this.panel9.Location = new System.Drawing.Point(268, 467);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(225, 358);
            this.panel9.TabIndex = 3;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(51, 309);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(146, 15);
            this.label11.TabIndex = 2;
            this.label11.Text = "Official ✭\t৳69,999 8/128 GB";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label12.Location = new System.Drawing.Point(3, 268);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(212, 21);
            this.label12.TabIndex = 1;
            this.label12.Text = "Samsung Galaxy S21 FE 5G";
            // 
            // iconButton6
            // 
            this.iconButton6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(236)))), ((int)(((byte)(232)))));
            this.iconButton6.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.iconButton6.IconChar = FontAwesome.Sharp.IconChar.ShoppingBasket;
            this.iconButton6.IconColor = System.Drawing.Color.Black;
            this.iconButton6.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton6.IconSize = 35;
            this.iconButton6.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton6.Location = new System.Drawing.Point(-2, 327);
            this.iconButton6.Name = "iconButton6";
            this.iconButton6.Size = new System.Drawing.Size(225, 29);
            this.iconButton6.TabIndex = 0;
            this.iconButton6.Text = "Buy";
            this.iconButton6.UseVisualStyleBackColor = false;
            // 
            // panel8
            // 
            this.panel8.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel8.BackgroundImage")));
            this.panel8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel8.Controls.Add(this.label9);
            this.panel8.Controls.Add(this.label10);
            this.panel8.Controls.Add(this.iconButton5);
            this.panel8.Location = new System.Drawing.Point(17, 467);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(225, 358);
            this.panel8.TabIndex = 4;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(51, 309);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(146, 15);
            this.label9.TabIndex = 2;
            this.label9.Text = "Official ✭\t৳43,999 8/128 GB";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label10.Location = new System.Drawing.Point(3, 268);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(193, 21);
            this.label10.TabIndex = 1;
            this.label10.Text = "Samsung Galaxy A53 5G";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // iconButton5
            // 
            this.iconButton5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(236)))), ((int)(((byte)(232)))));
            this.iconButton5.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.iconButton5.IconChar = FontAwesome.Sharp.IconChar.ShoppingBasket;
            this.iconButton5.IconColor = System.Drawing.Color.Black;
            this.iconButton5.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton5.IconSize = 35;
            this.iconButton5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton5.Location = new System.Drawing.Point(-2, 327);
            this.iconButton5.Name = "iconButton5";
            this.iconButton5.Size = new System.Drawing.Size(225, 29);
            this.iconButton5.TabIndex = 0;
            this.iconButton5.Text = "Buy";
            this.iconButton5.UseVisualStyleBackColor = false;
            // 
            // panel7
            // 
            this.panel7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel7.BackgroundImage")));
            this.panel7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel7.Controls.Add(this.label7);
            this.panel7.Controls.Add(this.label8);
            this.panel7.Controls.Add(this.iconButton4);
            this.panel7.Location = new System.Drawing.Point(755, 91);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(225, 358);
            this.panel7.TabIndex = 3;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(51, 309);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(113, 15);
            this.label7.TabIndex = 2;
            this.label7.Text = "Official :162,999 BDT";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label8.Location = new System.Drawing.Point(3, 268);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(202, 21);
            this.label8.TabIndex = 1;
            this.label8.Text = "Apple iphone 13 pro max";
            // 
            // iconButton4
            // 
            this.iconButton4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(236)))), ((int)(((byte)(232)))));
            this.iconButton4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.iconButton4.IconChar = FontAwesome.Sharp.IconChar.ShoppingBasket;
            this.iconButton4.IconColor = System.Drawing.Color.Black;
            this.iconButton4.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton4.IconSize = 35;
            this.iconButton4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton4.Location = new System.Drawing.Point(-2, 327);
            this.iconButton4.Name = "iconButton4";
            this.iconButton4.Size = new System.Drawing.Size(225, 29);
            this.iconButton4.TabIndex = 0;
            this.iconButton4.Text = "Buy";
            this.iconButton4.UseVisualStyleBackColor = false;
            // 
            // panel6
            // 
            this.panel6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel6.BackgroundImage")));
            this.panel6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel6.Controls.Add(this.label5);
            this.panel6.Controls.Add(this.label6);
            this.panel6.Controls.Add(this.iconButton3);
            this.panel6.Location = new System.Drawing.Point(513, 91);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(225, 358);
            this.panel6.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(51, 309);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(102, 15);
            this.label5.TabIndex = 2;
            this.label5.Text = "Official ✭\t৳189,999";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(3, 268);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(220, 21);
            this.label6.TabIndex = 1;
            this.label6.Text = "Samsung Galaxy Z Fold3 5G";
            // 
            // iconButton3
            // 
            this.iconButton3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(236)))), ((int)(((byte)(232)))));
            this.iconButton3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.iconButton3.IconChar = FontAwesome.Sharp.IconChar.ShoppingBasket;
            this.iconButton3.IconColor = System.Drawing.Color.Black;
            this.iconButton3.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton3.IconSize = 35;
            this.iconButton3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton3.Location = new System.Drawing.Point(-2, 327);
            this.iconButton3.Name = "iconButton3";
            this.iconButton3.Size = new System.Drawing.Size(225, 29);
            this.iconButton3.TabIndex = 0;
            this.iconButton3.Text = "Buy";
            this.iconButton3.UseVisualStyleBackColor = false;
            // 
            // panel5
            // 
            this.panel5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel5.BackgroundImage")));
            this.panel5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel5.Controls.Add(this.label3);
            this.panel5.Controls.Add(this.label4);
            this.panel5.Controls.Add(this.iconButton2);
            this.panel5.Location = new System.Drawing.Point(268, 91);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(225, 358);
            this.panel5.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(51, 309);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(102, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "Official :৳143,999";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(3, 268);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(209, 21);
            this.label4.TabIndex = 1;
            this.label4.Text = "Samsung Galaxy S22 Ultra";
            // 
            // iconButton2
            // 
            this.iconButton2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(236)))), ((int)(((byte)(232)))));
            this.iconButton2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.iconButton2.IconChar = FontAwesome.Sharp.IconChar.ShoppingBasket;
            this.iconButton2.IconColor = System.Drawing.Color.Black;
            this.iconButton2.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton2.IconSize = 35;
            this.iconButton2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton2.Location = new System.Drawing.Point(-2, 327);
            this.iconButton2.Name = "iconButton2";
            this.iconButton2.Size = new System.Drawing.Size(225, 29);
            this.iconButton2.TabIndex = 0;
            this.iconButton2.Text = "Buy";
            this.iconButton2.UseVisualStyleBackColor = false;
            // 
            // panel4
            // 
            this.panel4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel4.BackgroundImage")));
            this.panel4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel4.Controls.Add(this.label2);
            this.panel4.Controls.Add(this.label1);
            this.panel4.Controls.Add(this.iconButton1);
            this.panel4.Location = new System.Drawing.Point(17, 91);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(225, 358);
            this.panel4.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(51, 309);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(102, 15);
            this.label2.TabIndex = 2;
            this.label2.Text = "Official ✭\t৳114,999";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(23, 268);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(178, 21);
            this.label1.TabIndex = 1;
            this.label1.Text = "Samsung Galaxy S22+";
            // 
            // iconButton1
            // 
            this.iconButton1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(236)))), ((int)(((byte)(232)))));
            this.iconButton1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.iconButton1.IconChar = FontAwesome.Sharp.IconChar.ShoppingBasket;
            this.iconButton1.IconColor = System.Drawing.Color.Black;
            this.iconButton1.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton1.IconSize = 35;
            this.iconButton1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton1.Location = new System.Drawing.Point(-2, 327);
            this.iconButton1.Name = "iconButton1";
            this.iconButton1.Size = new System.Drawing.Size(225, 29);
            this.iconButton1.TabIndex = 0;
            this.iconButton1.Text = "Buy";
            this.iconButton1.UseVisualStyleBackColor = false;
            // 
            // Form15
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1364, 806);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "Form15";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form15";
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel27.ResumeLayout(false);
            this.panel27.PerformLayout();
            this.panel23.ResumeLayout(false);
            this.panel23.PerformLayout();
            this.panel28.ResumeLayout(false);
            this.panel28.PerformLayout();
            this.panel16.ResumeLayout(false);
            this.panel16.PerformLayout();
            this.panel29.ResumeLayout(false);
            this.panel29.PerformLayout();
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            this.panel30.ResumeLayout(false);
            this.panel30.PerformLayout();
            this.panel24.ResumeLayout(false);
            this.panel24.PerformLayout();
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            this.panel17.ResumeLayout(false);
            this.panel17.PerformLayout();
            this.panel25.ResumeLayout(false);
            this.panel25.PerformLayout();
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.panel26.ResumeLayout(false);
            this.panel26.PerformLayout();
            this.panel18.ResumeLayout(false);
            this.panel18.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel19.ResumeLayout(false);
            this.panel19.PerformLayout();
            this.panel20.ResumeLayout(false);
            this.panel20.PerformLayout();
            this.panel21.ResumeLayout(false);
            this.panel21.PerformLayout();
            this.panel22.ResumeLayout(false);
            this.panel22.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private FontAwesome.Sharp.IconButton iconButton24;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private FontAwesome.Sharp.IconButton iconButton20;
        private System.Windows.Forms.Panel panel28;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private FontAwesome.Sharp.IconButton iconButton25;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private FontAwesome.Sharp.IconButton iconButton13;
        private System.Windows.Forms.Panel panel29;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label52;
        private FontAwesome.Sharp.IconButton iconButton26;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private FontAwesome.Sharp.IconButton iconButton12;
        private System.Windows.Forms.Panel panel30;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label54;
        private FontAwesome.Sharp.IconButton iconButton27;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private FontAwesome.Sharp.IconButton iconButton21;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private FontAwesome.Sharp.IconButton iconButton11;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private FontAwesome.Sharp.IconButton iconButton14;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private FontAwesome.Sharp.IconButton iconButton22;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private FontAwesome.Sharp.IconButton iconButton10;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private FontAwesome.Sharp.IconButton iconButton9;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private FontAwesome.Sharp.IconButton iconButton23;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private FontAwesome.Sharp.IconButton iconButton15;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private FontAwesome.Sharp.IconButton iconButton8;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private FontAwesome.Sharp.IconButton iconButton7;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private FontAwesome.Sharp.IconButton iconButton17;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private FontAwesome.Sharp.IconButton iconButton18;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private FontAwesome.Sharp.IconButton iconButton19;
        private FontAwesome.Sharp.IconButton iconButton16;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private FontAwesome.Sharp.IconButton iconButton6;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private FontAwesome.Sharp.IconButton iconButton5;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private FontAwesome.Sharp.IconButton iconButton4;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private FontAwesome.Sharp.IconButton iconButton3;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private FontAwesome.Sharp.IconButton iconButton2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private FontAwesome.Sharp.IconButton iconButton1;
        private FontAwesome.Sharp.IconButton xiaomibut;
        private FontAwesome.Sharp.IconButton oppoBut;
        private FontAwesome.Sharp.IconButton viviBut;
        private FontAwesome.Sharp.IconButton SamsungBut;
        private FontAwesome.Sharp.IconButton iconButton28;
        private System.Windows.Forms.Button button1;
    }
}