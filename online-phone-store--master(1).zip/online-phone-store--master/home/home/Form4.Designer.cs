﻿
namespace home
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form4));
            this.signup = new FontAwesome.Sharp.IconButton();
            this.iconButton11 = new FontAwesome.Sharp.IconButton();
            this.Signin = new FontAwesome.Sharp.IconButton();
            this.iconButton10 = new FontAwesome.Sharp.IconButton();
            this.iconButton9 = new FontAwesome.Sharp.IconButton();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.iconButton8 = new FontAwesome.Sharp.IconButton();
            this.Menu3dot = new FontAwesome.Sharp.IconButton();
            this.Exit = new FontAwesome.Sharp.IconButton();
            this.Buy = new FontAwesome.Sharp.IconButton();
            this.iconButton3 = new FontAwesome.Sharp.IconButton();
            this.Home = new FontAwesome.Sharp.IconButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.iconButton1 = new FontAwesome.Sharp.IconButton();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.panel20 = new System.Windows.Forms.Panel();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.panel21 = new System.Windows.Forms.Panel();
            this.panel18 = new System.Windows.Forms.Panel();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.panel19 = new System.Windows.Forms.Panel();
            this.panel16 = new System.Windows.Forms.Panel();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.panel14 = new System.Windows.Forms.Panel();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.panel17 = new System.Windows.Forms.Panel();
            this.panel15 = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.panel13 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.panel22 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel23 = new System.Windows.Forms.Panel();
            this.panel3.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel20.SuspendLayout();
            this.panel18.SuspendLayout();
            this.panel16.SuspendLayout();
            this.panel14.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel22.SuspendLayout();
            this.SuspendLayout();
            // 
            // signup
            // 
            this.signup.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.signup.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(236)))), ((int)(((byte)(232)))));
            this.signup.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.signup.FlatAppearance.BorderSize = 0;
            this.signup.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.signup.ForeColor = System.Drawing.Color.Black;
            this.signup.IconChar = FontAwesome.Sharp.IconChar.SignOutAlt;
            this.signup.IconColor = System.Drawing.Color.Black;
            this.signup.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.signup.IconSize = 30;
            this.signup.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.signup.Location = new System.Drawing.Point(1610, 49);
            this.signup.Name = "signup";
            this.signup.Size = new System.Drawing.Size(118, 24);
            this.signup.TabIndex = 10;
            this.signup.Tag = "Signup";
            this.signup.Text = "sign up";
            this.signup.UseVisualStyleBackColor = false;
            this.signup.Click += new System.EventHandler(this.signup_Click);
            // 
            // iconButton11
            // 
            this.iconButton11.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.iconButton11.FlatAppearance.BorderSize = 0;
            this.iconButton11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton11.ForeColor = System.Drawing.Color.Black;
            this.iconButton11.IconChar = FontAwesome.Sharp.IconChar.Bars;
            this.iconButton11.IconColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.iconButton11.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton11.IconSize = 30;
            this.iconButton11.Location = new System.Drawing.Point(1669, 0);
            this.iconButton11.Name = "iconButton11";
            this.iconButton11.Size = new System.Drawing.Size(33, 26);
            this.iconButton11.TabIndex = 9;
            this.iconButton11.UseVisualStyleBackColor = true;
            this.iconButton11.Click += new System.EventHandler(this.iconButton11_Click);
            // 
            // Signin
            // 
            this.Signin.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Signin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(236)))), ((int)(((byte)(232)))));
            this.Signin.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.Signin.FlatAppearance.BorderSize = 0;
            this.Signin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Signin.ForeColor = System.Drawing.Color.Black;
            this.Signin.IconChar = FontAwesome.Sharp.IconChar.SignInAlt;
            this.Signin.IconColor = System.Drawing.Color.Black;
            this.Signin.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.Signin.IconSize = 30;
            this.Signin.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Signin.Location = new System.Drawing.Point(1610, 22);
            this.Signin.Name = "Signin";
            this.Signin.Size = new System.Drawing.Size(118, 24);
            this.Signin.TabIndex = 9;
            this.Signin.Tag = "Sign in";
            this.Signin.Text = "Sign in";
            this.Signin.UseVisualStyleBackColor = false;
            this.Signin.Click += new System.EventHandler(this.Signin_Click);
            // 
            // iconButton10
            // 
            this.iconButton10.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.iconButton10.FlatAppearance.BorderSize = 0;
            this.iconButton10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton10.ForeColor = System.Drawing.Color.Black;
            this.iconButton10.IconChar = FontAwesome.Sharp.IconChar.Bars;
            this.iconButton10.IconColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.iconButton10.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton10.IconSize = 30;
            this.iconButton10.Location = new System.Drawing.Point(1610, 1);
            this.iconButton10.Name = "iconButton10";
            this.iconButton10.Size = new System.Drawing.Size(92, 25);
            this.iconButton10.TabIndex = 8;
            this.iconButton10.UseVisualStyleBackColor = true;
            this.iconButton10.Click += new System.EventHandler(this.iconButton10_Click);
            // 
            // iconButton9
            // 
            this.iconButton9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.iconButton9.FlatAppearance.BorderSize = 0;
            this.iconButton9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton9.ForeColor = System.Drawing.Color.Black;
            this.iconButton9.IconChar = FontAwesome.Sharp.IconChar.Bars;
            this.iconButton9.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(81)))), ((int)(((byte)(65)))));
            this.iconButton9.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton9.IconSize = 30;
            this.iconButton9.Location = new System.Drawing.Point(1694, 3);
            this.iconButton9.Name = "iconButton9";
            this.iconButton9.Size = new System.Drawing.Size(34, 25);
            this.iconButton9.TabIndex = 1;
            this.iconButton9.UseVisualStyleBackColor = true;
            this.iconButton9.Click += new System.EventHandler(this.iconButton9_Click);
            // 
            // panel5
            // 
            this.panel5.Location = new System.Drawing.Point(38, 174);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(202, 94);
            this.panel5.TabIndex = 0;
            this.panel5.Paint += new System.Windows.Forms.PaintEventHandler(this.panel5_Paint);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Controls.Add(this.signup);
            this.panel3.Controls.Add(this.iconButton11);
            this.panel3.Controls.Add(this.Signin);
            this.panel3.Controls.Add(this.iconButton10);
            this.panel3.Controls.Add(this.iconButton9);
            this.panel3.Controls.Add(this.iconButton8);
            this.panel3.Controls.Add(this.panel5);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(181, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1038, 73);
            this.panel3.TabIndex = 7;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // iconButton8
            // 
            this.iconButton8.BackColor = System.Drawing.Color.Transparent;
            this.iconButton8.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.iconButton8.FlatAppearance.BorderSize = 0;
            this.iconButton8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton8.ForeColor = System.Drawing.Color.Black;
            this.iconButton8.IconChar = FontAwesome.Sharp.IconChar.Home;
            this.iconButton8.IconColor = System.Drawing.Color.Black;
            this.iconButton8.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton8.IconSize = 50;
            this.iconButton8.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton8.Location = new System.Drawing.Point(6, 3);
            this.iconButton8.Name = "iconButton8";
            this.iconButton8.Size = new System.Drawing.Size(150, 43);
            this.iconButton8.TabIndex = 7;
            this.iconButton8.Text = "Home";
            this.iconButton8.UseVisualStyleBackColor = false;
            this.iconButton8.Click += new System.EventHandler(this.iconButton8_Click);
            // 
            // Menu3dot
            // 
            this.Menu3dot.FlatAppearance.BorderSize = 0;
            this.Menu3dot.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Menu3dot.ForeColor = System.Drawing.Color.Black;
            this.Menu3dot.IconChar = FontAwesome.Sharp.IconChar.Bars;
            this.Menu3dot.IconColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Menu3dot.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.Menu3dot.IconSize = 30;
            this.Menu3dot.Location = new System.Drawing.Point(132, 3);
            this.Menu3dot.Name = "Menu3dot";
            this.Menu3dot.Size = new System.Drawing.Size(49, 32);
            this.Menu3dot.TabIndex = 0;
            this.Menu3dot.UseVisualStyleBackColor = true;
            this.Menu3dot.Click += new System.EventHandler(this.Menu3dot_Click);
            // 
            // Exit
            // 
            this.Exit.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.Exit.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.Exit.FlatAppearance.BorderSize = 0;
            this.Exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Exit.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Exit.IconChar = FontAwesome.Sharp.IconChar.Times;
            this.Exit.IconColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Exit.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.Exit.IconSize = 20;
            this.Exit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Exit.Location = new System.Drawing.Point(-7, 1389);
            this.Exit.Name = "Exit";
            this.Exit.Size = new System.Drawing.Size(69, 24);
            this.Exit.TabIndex = 6;
            this.Exit.Text = "Exit";
            this.Exit.UseVisualStyleBackColor = true;
            this.Exit.Click += new System.EventHandler(this.Exit_Click);
            // 
            // Buy
            // 
            this.Buy.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.Buy.FlatAppearance.BorderSize = 0;
            this.Buy.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Buy.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Buy.IconChar = FontAwesome.Sharp.IconChar.ShoppingBasket;
            this.Buy.IconColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Buy.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.Buy.IconSize = 30;
            this.Buy.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Buy.Location = new System.Drawing.Point(32, 254);
            this.Buy.Name = "Buy";
            this.Buy.Size = new System.Drawing.Size(130, 24);
            this.Buy.TabIndex = 3;
            this.Buy.Text = "Buy Phone";
            this.Buy.UseVisualStyleBackColor = true;
            this.Buy.Click += new System.EventHandler(this.Buy_Click);
            // 
            // iconButton3
            // 
            this.iconButton3.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.iconButton3.FlatAppearance.BorderSize = 0;
            this.iconButton3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.iconButton3.IconChar = FontAwesome.Sharp.IconChar.Mobile;
            this.iconButton3.IconColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.iconButton3.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton3.IconSize = 26;
            this.iconButton3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton3.Location = new System.Drawing.Point(32, 194);
            this.iconButton3.Name = "iconButton3";
            this.iconButton3.Size = new System.Drawing.Size(130, 30);
            this.iconButton3.TabIndex = 2;
            this.iconButton3.Text = "New Phone";
            this.iconButton3.UseVisualStyleBackColor = true;
            this.iconButton3.Click += new System.EventHandler(this.iconButton3_Click);
            // 
            // Home
            // 
            this.Home.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.Home.FlatAppearance.BorderSize = 0;
            this.Home.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Home.ForeColor = System.Drawing.Color.Black;
            this.Home.IconChar = FontAwesome.Sharp.IconChar.Home;
            this.Home.IconColor = System.Drawing.Color.Black;
            this.Home.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.Home.IconSize = 30;
            this.Home.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Home.Location = new System.Drawing.Point(32, 148);
            this.Home.Name = "Home";
            this.Home.Size = new System.Drawing.Size(130, 24);
            this.Home.TabIndex = 1;
            this.Home.Tag = "Home";
            this.Home.Text = "Home";
            this.Home.UseVisualStyleBackColor = true;
            this.Home.Click += new System.EventHandler(this.Home_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(236)))), ((int)(((byte)(232)))));
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.panel1.Controls.Add(this.iconButton1);
            this.panel1.Controls.Add(this.Exit);
            this.panel1.Controls.Add(this.Buy);
            this.panel1.Controls.Add(this.iconButton3);
            this.panel1.Controls.Add(this.Home);
            this.panel1.Controls.Add(this.panel6);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Font = new System.Drawing.Font("Bahnschrift Light", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(181, 775);
            this.panel1.TabIndex = 6;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // iconButton1
            // 
            this.iconButton1.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.iconButton1.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.iconButton1.FlatAppearance.BorderSize = 0;
            this.iconButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconButton1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.iconButton1.IconChar = FontAwesome.Sharp.IconChar.SignOutAlt;
            this.iconButton1.IconColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.iconButton1.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton1.IconSize = 20;
            this.iconButton1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconButton1.Location = new System.Drawing.Point(32, 739);
            this.iconButton1.Name = "iconButton1";
            this.iconButton1.Size = new System.Drawing.Size(99, 24);
            this.iconButton1.TabIndex = 7;
            this.iconButton1.Text = "Sign out";
            this.iconButton1.UseVisualStyleBackColor = true;
            this.iconButton1.Click += new System.EventHandler(this.iconButton1_Click);
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.Menu3dot);
            this.panel6.Location = new System.Drawing.Point(0, 0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(181, 84);
            this.panel6.TabIndex = 0;
            this.panel6.Paint += new System.Windows.Forms.PaintEventHandler(this.panel6_Paint);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1219, 775);
            this.panel2.TabIndex = 8;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.panel7);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1219, 775);
            this.panel4.TabIndex = 0;
            this.panel4.Paint += new System.Windows.Forms.PaintEventHandler(this.panel4_Paint);
            // 
            // panel7
            // 
            this.panel7.AutoScroll = true;
            this.panel7.Controls.Add(this.label4);
            this.panel7.Controls.Add(this.panel20);
            this.panel7.Controls.Add(this.panel21);
            this.panel7.Controls.Add(this.panel18);
            this.panel7.Controls.Add(this.panel19);
            this.panel7.Controls.Add(this.panel16);
            this.panel7.Controls.Add(this.panel14);
            this.panel7.Controls.Add(this.panel17);
            this.panel7.Controls.Add(this.panel15);
            this.panel7.Controls.Add(this.panel12);
            this.panel7.Controls.Add(this.panel8);
            this.panel7.Controls.Add(this.panel13);
            this.panel7.Controls.Add(this.panel10);
            this.panel7.Controls.Add(this.panel9);
            this.panel7.Controls.Add(this.panel11);
            this.panel7.Controls.Add(this.panel22);
            this.panel7.Controls.Add(this.panel23);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel7.Location = new System.Drawing.Point(0, 0);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(1219, 775);
            this.panel7.TabIndex = 0;
            this.panel7.Paint += new System.Windows.Forms.PaintEventHandler(this.panel7_Paint);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(236)))), ((int)(((byte)(232)))));
            this.label4.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(354, 76);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(610, 25);
            this.label4.TabIndex = 31;
            this.label4.Text = "Welcome to Wipup the country largest Phone exchanging platform";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // panel20
            // 
            this.panel20.Controls.Add(this.label23);
            this.panel20.Controls.Add(this.label24);
            this.panel20.Location = new System.Drawing.Point(928, 630);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(240, 103);
            this.panel20.TabIndex = 30;
            this.panel20.Paint += new System.Windows.Forms.PaintEventHandler(this.panel20_Paint);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(29, 39);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(146, 15);
            this.label23.TabIndex = 1;
            this.label23.Text = "Official ✭\t৳33,990 8/128 GB";
            this.label23.Click += new System.EventHandler(this.label23_Click);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label24.Location = new System.Drawing.Point(26, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(192, 20);
            this.label24.TabIndex = 0;
            this.label24.Text = "Realme Gt Master eidition";
            this.label24.Click += new System.EventHandler(this.label24_Click);
            // 
            // panel21
            // 
            this.panel21.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel21.BackgroundImage")));
            this.panel21.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel21.Location = new System.Drawing.Point(928, 431);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(240, 210);
            this.panel21.TabIndex = 29;
            this.panel21.Paint += new System.Windows.Forms.PaintEventHandler(this.panel21_Paint);
            // 
            // panel18
            // 
            this.panel18.Controls.Add(this.label20);
            this.panel18.Controls.Add(this.label21);
            this.panel18.Location = new System.Drawing.Point(682, 630);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(240, 103);
            this.panel18.TabIndex = 28;
            this.panel18.Paint += new System.Windows.Forms.PaintEventHandler(this.panel18_Paint);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(67, 39);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(96, 15);
            this.label20.TabIndex = 1;
            this.label20.Text = "Official ✭\t৳32,990";
            this.label20.Click += new System.EventHandler(this.label20_Click);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label21.Location = new System.Drawing.Point(67, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(96, 20);
            this.label21.TabIndex = 0;
            this.label21.Text = "Oppo Reno5";
            this.label21.Click += new System.EventHandler(this.label21_Click);
            // 
            // panel19
            // 
            this.panel19.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel19.BackgroundImage")));
            this.panel19.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel19.Location = new System.Drawing.Point(682, 431);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(240, 210);
            this.panel19.TabIndex = 27;
            this.panel19.Paint += new System.Windows.Forms.PaintEventHandler(this.panel19_Paint);
            // 
            // panel16
            // 
            this.panel16.Controls.Add(this.label17);
            this.panel16.Controls.Add(this.label18);
            this.panel16.Location = new System.Drawing.Point(433, 630);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(240, 103);
            this.panel16.TabIndex = 21;
            this.panel16.Paint += new System.Windows.Forms.PaintEventHandler(this.panel16_Paint);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(64, 39);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(96, 15);
            this.label17.TabIndex = 1;
            this.label17.Text = "Official ✭\t৳32,990";
            this.label17.Click += new System.EventHandler(this.label17_Click);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label18.Location = new System.Drawing.Point(64, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(96, 20);
            this.label18.TabIndex = 0;
            this.label18.Text = "Oppo Reno6";
            this.label18.Click += new System.EventHandler(this.label18_Click);
            // 
            // panel14
            // 
            this.panel14.Controls.Add(this.label14);
            this.panel14.Controls.Add(this.label15);
            this.panel14.Location = new System.Drawing.Point(187, 630);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(240, 103);
            this.panel14.TabIndex = 26;
            this.panel14.Paint += new System.Windows.Forms.PaintEventHandler(this.panel14_Paint);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(66, 39);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(90, 15);
            this.label14.TabIndex = 1;
            this.label14.Text = "Official ✭\t৳9,599";
            this.label14.Click += new System.EventHandler(this.label14_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label15.Location = new System.Drawing.Point(58, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(114, 20);
            this.label15.TabIndex = 0;
            this.label15.Text = "Symphony Z42";
            this.label15.Click += new System.EventHandler(this.label15_Click);
            // 
            // panel17
            // 
            this.panel17.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel17.BackgroundImage")));
            this.panel17.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel17.Location = new System.Drawing.Point(434, 431);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(240, 210);
            this.panel17.TabIndex = 18;
            this.panel17.Paint += new System.Windows.Forms.PaintEventHandler(this.panel17_Paint);
            // 
            // panel15
            // 
            this.panel15.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel15.BackgroundImage")));
            this.panel15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel15.Location = new System.Drawing.Point(188, 431);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(240, 210);
            this.panel15.TabIndex = 25;
            this.panel15.Paint += new System.Windows.Forms.PaintEventHandler(this.panel15_Paint);
            // 
            // panel12
            // 
            this.panel12.Controls.Add(this.label11);
            this.panel12.Controls.Add(this.label12);
            this.panel12.Location = new System.Drawing.Point(925, 322);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(240, 103);
            this.panel12.TabIndex = 24;
            this.panel12.Paint += new System.Windows.Forms.PaintEventHandler(this.panel12_Paint);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(65, 39);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(99, 15);
            this.label11.TabIndex = 1;
            this.label11.Text = "Official ✭\t৳39,990 ";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label12.Location = new System.Drawing.Point(65, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(105, 20);
            this.label12.TabIndex = 0;
            this.label12.Text = "VIVO V23 pro";
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.label5);
            this.panel8.Controls.Add(this.label6);
            this.panel8.Location = new System.Drawing.Point(679, 322);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(240, 103);
            this.panel8.TabIndex = 22;
            this.panel8.Paint += new System.Windows.Forms.PaintEventHandler(this.panel8_Paint);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(70, 39);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(105, 15);
            this.label5.TabIndex = 1;
            this.label5.Text = "Official ✭\t৳143,999 ";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(29, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(193, 20);
            this.label6.TabIndex = 0;
            this.label6.Text = "Samsung Galaxy S22 Ultra";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // panel13
            // 
            this.panel13.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel13.BackgroundImage")));
            this.panel13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel13.Location = new System.Drawing.Point(925, 123);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(240, 210);
            this.panel13.TabIndex = 23;
            this.panel13.Paint += new System.Windows.Forms.PaintEventHandler(this.panel13_Paint);
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.label7);
            this.panel10.Controls.Add(this.label8);
            this.panel10.Controls.Add(this.label9);
            this.panel10.Location = new System.Drawing.Point(433, 322);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(240, 103);
            this.panel10.TabIndex = 20;
            this.panel10.Paint += new System.Windows.Forms.PaintEventHandler(this.panel10_Paint);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(29, 54);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(141, 15);
            this.label7.TabIndex = 2;
            this.label7.Text = "Official ✭\t৳162,999  256GB";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(29, 39);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(143, 15);
            this.label8.TabIndex = 1;
            this.label8.Text = "Official ✭৳147,999 128GB";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label9.Location = new System.Drawing.Point(18, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(208, 20);
            this.label9.TabIndex = 0;
            this.label9.Text = "Model: Apple iPhone 13 Pro ";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // panel9
            // 
            this.panel9.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel9.BackgroundImage")));
            this.panel9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel9.Location = new System.Drawing.Point(679, 123);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(240, 210);
            this.panel9.TabIndex = 19;
            this.panel9.Paint += new System.Windows.Forms.PaintEventHandler(this.panel9_Paint);
            // 
            // panel11
            // 
            this.panel11.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel11.BackgroundImage")));
            this.panel11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel11.Location = new System.Drawing.Point(433, 123);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(240, 210);
            this.panel11.TabIndex = 17;
            this.panel11.Paint += new System.Windows.Forms.PaintEventHandler(this.panel11_Paint);
            // 
            // panel22
            // 
            this.panel22.Controls.Add(this.label3);
            this.panel22.Controls.Add(this.label2);
            this.panel22.Controls.Add(this.label1);
            this.panel22.Location = new System.Drawing.Point(187, 322);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(240, 103);
            this.panel22.TabIndex = 16;
            this.panel22.Paint += new System.Windows.Forms.PaintEventHandler(this.panel22_Paint);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(29, 54);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(143, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "Official ✭\t৳৳176,999 256GB";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(29, 39);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(138, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "Official ✭\t৳162,999 128GB";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(238, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Model: Apple iPhone 13 Pro Max";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // panel23
            // 
            this.panel23.BackgroundImage = global::home.Properties.Resources._22;
            this.panel23.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel23.Location = new System.Drawing.Point(187, 123);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(240, 210);
            this.panel23.TabIndex = 15;
            this.panel23.Paint += new System.Windows.Forms.PaintEventHandler(this.panel23_Paint);
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::home.Properties.Resources._41;
            this.ClientSize = new System.Drawing.Size(1219, 775);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Name = "Form4";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form4";
            this.panel3.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel20.ResumeLayout(false);
            this.panel20.PerformLayout();
            this.panel18.ResumeLayout(false);
            this.panel18.PerformLayout();
            this.panel16.ResumeLayout(false);
            this.panel16.PerformLayout();
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel22.ResumeLayout(false);
            this.panel22.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private FontAwesome.Sharp.IconButton signup;
        private FontAwesome.Sharp.IconButton iconButton11;
        private FontAwesome.Sharp.IconButton Signin;
        private FontAwesome.Sharp.IconButton iconButton10;
        private FontAwesome.Sharp.IconButton iconButton9;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel3;
        private FontAwesome.Sharp.IconButton iconButton8;
        private FontAwesome.Sharp.IconButton Menu3dot;
        private FontAwesome.Sharp.IconButton Exit;
        private FontAwesome.Sharp.IconButton Buy;
        private FontAwesome.Sharp.IconButton iconButton3;
        private FontAwesome.Sharp.IconButton Home;
        internal System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel2;
        private FontAwesome.Sharp.IconButton iconButton1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel23;
    }
}